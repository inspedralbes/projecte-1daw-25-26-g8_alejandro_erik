<?php
require_once __DIR__ . '/vendor/autoload.php';

try {
    $mongoClient = new MongoDB\Client(
        "mongodb://root:example@mongo:27017/?authSource=admin"
    );

    $mongoDB    = $mongoClient->selectDatabase('incidencies_log');
    $collection = $mongoDB->selectCollection('logs');

} catch (Exception $e) {
    die("Error connexió MongoDB: " . $e->getMessage());
}

function logAccio(string $accio, array $dades): void {
    global $collection;

    $collection->insertOne([
        'accio'     => $accio,
        'dades'     => $dades,
        'timestamp' => new MongoDB\BSON\UTCDateTime(),
        'usuari'    => $_SESSION['usuari'] ?? 'anònim',
    ]);
}

function getHistorial(int $limit = 50): array {
    global $collection;

    $cursor = $collection->find(
        [],
        ['sort' => ['timestamp' => -1], 'limit' => $limit]
    );

    return iterator_to_array($cursor);
}
?>