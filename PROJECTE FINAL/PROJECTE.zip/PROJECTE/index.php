<?php include 'includes/capcalera.php'; ?>

<h1 class="page-title">Institut Pedralbes &mdash; Sistema de Gestió d'Incidències</h1>
<p class="text-muted">Benvingut. Selecciona una opció:</p>

<div class="row mt-4">
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">📝 Nova Incidència</h5>
                <p class="card-text">Registra una nova incidència informàtica.</p>
                <a href="crear_incidencies.php" class="btn btn-primary">Anar</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">🔍 Estat Incidència</h5>
                <p class="card-text">Consulta l'estat i les actuacions d'una incidència pel seu codi.</p>
                <a href="estat_incidencia.php" class="btn btn-primary">Anar</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">📋 Llistat d'Incidències</h5>
                <p class="card-text">Veure totes les incidències registrades, ordenades per prioritat.</p>
                <a href="incidencies.php" class="btn btn-primary">Anar</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">✏️ Modificar Incidència</h5>
                <p class="card-text">Assignar tècnic i prioritat a incidències no resoltes.</p>
                <a href="detall_incidencia.php" class="btn btn-warning">Anar</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">🔧 Registrar Actuació</h5>
                <p class="card-text">Afegir una actuació tècnica a una incidència existent.</p>
                <a href="afegir_actuacio.php" class="btn btn-warning">Anar</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">📊 Informe de Tècnics</h5>
                <p class="card-text">Incidències obertes per tècnic, agrupades per prioritat.</p>
                <a href="informe_tecnics.php" class="btn btn-info">Anar</a>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card h-100">
            <div class="card-body">
                <h5 class="card-title">🏢 Consum per Departaments</h5>
                <p class="card-text">Nombre d'incidències i temps total per cada departament.</p>
                <a href="consum_departaments.php" class="btn btn-info">Anar</a>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/peu.php'; ?>