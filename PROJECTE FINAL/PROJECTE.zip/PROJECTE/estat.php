<?php
include 'conexio.php';
include 'includes/capcalera.php';

$id = isset($_POST['id']) ? intval($_POST['id']) : (isset($_GET['id']) ? intval($_GET['id']) : 0);
?>

<h1 class="page-title">Estat d'una Incidència</h1>

<form method="POST">
    <div class="row g-2 align-items-end mb-4">
        <div class="col-auto">
            <label class="form-label">Codi de la incidència:</label>
            <input type="number" name="id" class="form-control" value="<?php echo $id ?: ''; ?>" placeholder="Ex: 1" min="1">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-primary">Consultar</button>
        </div>
    </div>
</form>

<?php if ($id > 0):
    $stmt = $conn->prepare("
        SELECT i.*, d.nom AS nom_departament, t.nom AS nom_tecnic
        FROM INCIDENCIA i
        LEFT JOIN DEPARTAMENT d ON i.id_departament = d.id_departament
        LEFT JOIN TECNIC t      ON i.id_tecnic      = t.id_tecnic
        WHERE i.id_incidencia = ?
    ");
    $stmt->execute([$id]);
    $inc = $stmt->fetch();
?>
    <?php if (!$inc): ?>
        <div class="alert alert-warning">No s'ha trobat cap incidència amb el codi <strong><?php echo $id; ?></strong>.</div>
    <?php else: ?>
        <div class="card mb-4">
            <div class="card-header fw-bold">Incidència #<?php echo $inc['id_incidencia']; ?></div>
            <div class="card-body">
                <p><strong>Departament:</strong> <?php echo htmlspecialchars($inc['nom_departament'] ?? '-'); ?></p>
                <p><strong>Data creació:</strong> <?php echo $inc['data_creacio']; ?></p>
                <p><strong>Descripció:</strong> <?php echo htmlspecialchars($inc['descripcio']); ?></p>
                <p><strong>Prioritat:</strong> <?php echo $inc['prioritat'] ?? 'Pendent d\'assignar'; ?></p>
                <p><strong>Tècnic:</strong> <?php echo htmlspecialchars($inc['nom_tecnic'] ?? 'Sense assignar'); ?></p>
                <p><strong>Estat:</strong>
                    <?php if ($inc['estat'] === 'tancada'): ?>
                        <span class="badge bg-success">Tancada <?php echo $inc['data_finalitzacio'] ? '(' . $inc['data_finalitzacio'] . ')' : ''; ?></span>
                    <?php elseif ($inc['estat'] === 'en_proces'): ?>
                        <span class="badge bg-primary">En procés</span>
                    <?php else: ?>
                        <span class="badge bg-warning text-dark">Oberta</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>

        <h4>Actuacions visibles:</h4>
        <?php
        $stmt2 = $conn->prepare("
            SELECT a.*, t.nom AS nom_tecnic
            FROM ACTUACIO a
            LEFT JOIN TECNIC t ON a.id_tecnic = t.id_tecnic
            WHERE a.id_incidencia = ? AND a.visible_usuari = 1
            ORDER BY a.data_actuacio ASC
        ");
        $stmt2->execute([$id]);
        $actuacions = $stmt2->fetchAll();
        ?>
        <?php if (empty($actuacions)): ?>
            <p class="text-muted">Encara no hi ha actuacions visibles per aquesta incidència.</p>
        <?php else: ?>
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr><th>Data</th><th>Tècnic</th><th>Descripció</th><th>Temps (min)</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($actuacions as $act): ?>
                        <tr>
                            <td><?php echo $act['data_actuacio']; ?></td>
                            <td><?php echo htmlspecialchars($act['nom_tecnic'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($act['descripcio']); ?></td>
                            <td><?php echo $act['temps_dedicat']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>

<?php include 'includes/peu.php'; ?>